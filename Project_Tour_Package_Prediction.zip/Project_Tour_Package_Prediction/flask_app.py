
# A very simple Flask Hello World app for you to get started with...

from flask import Flask, request, render_template
import pandas as pd
import os
print(os.getcwd())

model =pd.read_pickle(r'/home/sabkababa007/mysite/TourPackagePrediction.pkl')
cols = ['DurationOfPitch','Passport','Single','Married','Divorced','MonthlyIncome','Basic','Company Invited','Free Lancer','NumberOfFollowups']

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello from Flask!'


@app.route('/tour_package_prediction',methods =['GET','POST'])
def tour_package_prediction():

    result =0

    if request.method == 'POST':
        DurationOfPitch =request.form['DurationOfPitch']
        Passport=request.form['Passport']
        Single=request.form['Single']
        Married=request.form['Married']
        Divorced=request.form['Divorced']
        MonthlyIncome=request.form['MonthlyIncome']
        Basic=request.form['Basic']
        Company_Invited=request.form['Company Invited']
        Free_Lancer=request.form['Free Lancer']
        NumberOfFollowups=request.form['NumberOfFollowups']

        query=pd.DataFrame({'DurationOfPitch':[DurationOfPitch],
                    'Passport':[Passport],
                    'Single':[Single],
                    'Married':[Married],
                    'Divorced':[Divorced],
                    'MonthlyIncome':[MonthlyIncome],
                    'Basic':[Basic],
                    'Company Invited':[Company_Invited],
                    'Free Lancer':[Free_Lancer],
                    'NumberOfFollowups':[NumberOfFollowups]})

        result= model.predict(query)[0]
        #result = round(model.predict(query)[0],1)

    return render_template('TourPackagePrediction.html',result =result)

@app.route('/about')
def about_page():
    return "This is my Machine Learning Project Website "
